<?php get_header() ?>
<br />
<div class="container fundo-branco">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<?php get_template_part('loop', 'search'); ?>
    </div>
</div>
<?php get_footer() ?>