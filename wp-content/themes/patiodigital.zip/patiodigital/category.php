<?php get_header() ?>
<div class="container">
	<?php get_template_part('loop', 'category'); ?>
    </div>
<?php get_footer() ?>