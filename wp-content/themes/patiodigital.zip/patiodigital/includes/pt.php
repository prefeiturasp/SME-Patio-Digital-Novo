<?php

// Constantes Portugues

define('BUSCAR', 'Buscar');

define('PROXIMO', 'Próximo');

define('ANTERIOR', 'Anterior');

define('VEJAMAIS', 'Ver mais');

define('VOLTAR', '<< Voltar');

define('FECHAR', 'Fechar');

define('OOOPS', 'OOOPS! Página não encontrada');

define('PEDIMOSDESCULPAS', 'Pedimos desculpas, mas a página que você acessou não está mais disponível! Pode ter sido removida ou alterada.');

define('UTILIZEOMENUACIMA', 'Utilize o menu acima para navegar');

define('ESTAPROCURANDO', 'Está procurando um dos seguintes itens ou páginas?');

define('RODAPE_CONTATO', 'Contato');

define('RODAPE_SIGANOS', 'Siga-nos');

define('COPYRIGHT', 'Copyright © 2017 Sua Empresa - Todos os direitos reservados.');

define('DESENVOLVIMENTO', 'Desenvolvido por: ');
?>