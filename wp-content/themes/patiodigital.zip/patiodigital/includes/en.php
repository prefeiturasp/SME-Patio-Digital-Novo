<?php

// Constantes Portugues

define('BUSCAR', 'Find');

define('PROXIMO', 'Next');

define('ANTERIOR', 'Previous');

define('VEJAMAIS', 'Moore');

define('VOLTAR', '<< Back');

define('FECHAR', 'Close');

define('OOOPS', 'OOOPS! Not Found');

define('PEDIMOSDESCULPAS', 'We apologize, but the page you requested is no longer available! It may have been removed or altered.');

define('UTILIZEOMENUACIMA', 'Use the menu above to navigate');

define('ESTAPROCURANDO', 'Are you looking for the following items or pages?');

define('RODAPE_CONTATO', 'Contact');

define('RODAPE_SIGANOS', 'Follow us');

define('COPYRIGHT', 'Copyright © 2017 Your Company - All rights reserved.');

define('DESENVOLVIMENTO', 'Developed by: ');

?>