<?php get_header() ?>
<div class="container fundo-branco">
    <?php
    get_template_part('loop', '404');
    ?>
</div>
<?php get_footer() ?>
