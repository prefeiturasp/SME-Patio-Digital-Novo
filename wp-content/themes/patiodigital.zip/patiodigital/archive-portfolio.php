<?php
use Classes\TemplateHierarchy\Portfolio\ArchivePortfolio;
get_header();
$template_hierarchy = new ArchivePortfolio();
get_footer()
?>
