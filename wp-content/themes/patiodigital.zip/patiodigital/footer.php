</div>
<!--main-->


<div class="container-fluid rodape margin-top-30">
    <div class="fa fa-angle-up" id="toTop" style="display: none;">

    </div>
	<div class="container">
        <div class="row">

                <div class="col-6"><img src="http://localhost/SME-PatioDigitalNovo/wp-content/uploads/2019/02/rodape-unesco.jpg" class="img-fluid aligncenter" alt=""></div>
                <div class="col-6"><img src="http://localhost/SME-PatioDigitalNovo/wp-content/uploads/2019/02/rodape-logo-prefeitura.jpg" class="img-fluid aligncenter" alt=""></div>


        </div>
    </div>
</div>


<!-- /.container-fluid -->
<?php wp_footer() ?>
</body>
</html>