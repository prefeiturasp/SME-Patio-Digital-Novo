<?php get_header() ?>
<div class="container">
        <?php get_template_part('loop', 'single'); ?>
    </div>
<?php get_footer() ?>
