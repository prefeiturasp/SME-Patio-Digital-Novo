<?php

namespace Classes\TemplateHierarchy\Portfolio;

use Classes\DesignPatterns\Factory;
use Classes\ModelosDePaginas\PaginaNumeroRandomicos;

class SinglePortfolio
{
    private $galeria;
    private $galeriaArray;
    private $attachament;

	public function __construct()
	{
	    $this->getFields();
		$this->montaConteudoSinglePortfolio();
	}

	public function getFields(){
	    $this->galeria =  get_field('escolha_as_imagens_do_portfolio');
	    $this->galeriaArray = explode(',', $this->galeria);
    }

    public function getAttachaments(){

		echo '<div class="container">';

		echo '<div class="row">';

	    foreach ($this->galeriaArray as $imgId){
	        echo '<div class="col-12 col-md-12 col-lg-4 col-xl-4">';
	        echo '<img class="img-fluid aligncenter" src="'.wp_get_attachment_url($imgId).'"/>';
	        echo '</div>';
        }

		echo '</div>';
		echo '</div>';

    }

	public function montaConteudoSinglePortfolio()
	{

		if (have_posts()) : while (have_posts()) : the_post(); ?>
            <div class="col-12">
            <div class="row">

                <div class='container'>
                    <h1 class="titulo-taxonomias">
						<?php the_title(); ?>
                    </h1>
					<?php if (has_post_thumbnail()) {
						the_post_thumbnail('medium', array('class' => 'img-fluid alignright', 'alt' => Factory::getAltTitleImagesThePostThumbnail()['alt'], 'title' => Factory::getAltTitleImagesThePostThumbnail()['title']));
					} ?>
					<?php the_content(); ?>
                </div>
            </div>
            </div>

		<?php
		endwhile;
		else: ?>
            <p>
				<?php _e('Não existem posts cadastrados.', 'patiodigital'); ?>
            </p>
		<?php endif;

		new PaginaNumeroRandomicos\PaginaNumeroRandomicos();

		$this->getAttachaments();


	}

}