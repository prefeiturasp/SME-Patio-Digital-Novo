<?php
namespace Classes\XTestes;

class TesteAutoload
{

	public function __construct()
	{
		echo '<h1>Ollyver Teste Autoload</h1>';
	}

}