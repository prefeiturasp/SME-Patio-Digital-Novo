jQuery(document).ready(function ($) {
    $('.colorPicker').wpColorPicker();
});