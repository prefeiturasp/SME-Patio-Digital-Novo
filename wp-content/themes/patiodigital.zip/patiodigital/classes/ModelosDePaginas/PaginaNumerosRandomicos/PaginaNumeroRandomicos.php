<?php


namespace Classes\ModelosDePaginas\PaginaNumeroRandomicos;


use Classes\PaginaFilha\PaginaFilha;

class PaginaNumeroRandomicos
{

	protected $numeros_randomicos_ID;
	protected $escolha_a_categoria_de_numeros_randomicos;
	protected $numero_animacao;
	protected $texto_apos_animacao;
	protected $deseja_exibir_titulo_conjunto_numero_randomicos;
	protected $titulo_conjunto_numeros_randomicos;
	protected $args_numeros_randomicos;
	protected $query_numeros_randomicos;



	public function __construct()
	{
		$this->page_ID_filha=PaginaFilha::getIdPaginaCorreta();
		$this->escolha_a_categoria_de_numeros_randomicos = get_field('escolha_a_categoria_de_numeros_randomicos', $this->page_ID_filha);
		$this->deseja_exibir_titulo_conjunto_numero_randomicos = get_field('deseja_exibir_titulo_conjunto_numero_randomicos', $this->page_ID_filha);
		$this->titulo_conjunto_numeros_randomicos = get_field('titulo_conjunto_numeros_randomicos', $this->page_ID_filha);

		$this->montaQueryPaginaNumerosRandomicos();
		$this->montaHtmlNumerosRandomicos();
	}

	public function montaQueryPaginaNumerosRandomicos(){

		$this->args_numeros_randomicos = array(
			'post_type' => 'numero_randomico',
			'orderby' => 'date',
			'order' => 'ASC',
			'tax_query' => array(
				array(
					'taxonomy' => 'categorias-numero-randomico',
					'field' => 'term_id',
					'terms' => $this->escolha_a_categoria_de_numeros_randomicos,
				)
			)
		);

		$this->query_numeros_randomicos = new \WP_Query($this->args_numeros_randomicos);

    }

    public function getTituloConjuntoNumerosRandomicos(){

		if ($this->deseja_exibir_titulo_conjunto_numero_randomicos == 'sim' && trim($this->titulo_conjunto_numeros_randomicos) != "") {
			return '<h3 class="titulo-numeros-randomicos">'.$this->titulo_conjunto_numeros_randomicos.'</h3>';
		}
    }

	public function montaHtmlNumerosRandomicos(){
		?>
        <div class="row background-numeros-randomicos" >
		<div class="container">

            <?= $this->getTituloConjuntoNumerosRandomicos() ?>

        <div class="row">
                <section class="container-numeros-randomicos ">
                    <div class="row">

					<?php
					if ($this->query_numeros_randomicos->have_posts()) {
						while ($this->query_numeros_randomicos->have_posts()) : $this->query_numeros_randomicos->the_post();
							$this->numero_animacao = get_field('numero_animacao');
							$this->texto_apos_animacao = get_field('texto_apos_animacao');

							?>

                            <div class="col">
                            <div class="">

                                <div class="container-numeros-randomicos-inner" id="id_container_<?php echo get_the_ID(); ?>">

                                    <!--Chama a Funçao que Cria os Números Randômicos-->
                                    <script type="text/javascript">
                                        jQuery(document).ready(function() {
                                            var idContainer = "#id_container_"+<?php echo get_the_ID(); ?>;
                                            criaNumerosRancomicos(idContainer);
                                        });
                                    </script>

                                    <span class="count wow zoomInUp" data-wow-delay="0.5s" title="<?php echo $this->texto_apos_animacao ?>"><?php echo $this->numero_animacao ?></span>
                                    <span class="texto-count" style="display: none"><?php echo $this->texto_apos_animacao ?></span>
                                </div>
                                <p class="titulo-cpt-numeros-randomicos"><?php the_title()?></p>
                            </div>
                            </div>
						<?php
						endwhile;
						wp_reset_postdata();
						?>
					<?php } ?>
                    </div>
                </section>

        </div>
        </div>
        </div>

		<?php

	}

}