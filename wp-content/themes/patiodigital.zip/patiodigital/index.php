<?php // A palava é prata, o silêncio é ouro ?>
