<div class="row container-trabalhos">
    <h2 style="margin-left: 15px;"><i class="fa fa-search-plus"></i> Resultados da pesquisa para "<?php echo $s ?>"</h2>
</div>

<?php
$exclude_ids = '147';
    $args = array(
        'post__not_in' => array($exclude_ids),
        'post_type' => array( 'post', 'page', 'destaque'),
        'paged' => get_query_var( 'paged' ),
        's' => $s,

    );

$argumentos = new WP_Query( $args );


?>

<?php if ( $argumentos->have_posts() ) : while ( $argumentos->have_posts() ) : $argumentos->the_post(); ?>
<div class="row container-category linha-pontilhada-category">
<!--    --><?php /*if ( have_posts() ) : while ( have_posts() ) : the_post(); */?>
    <h3 class="titulo-category"> <i class="fa fa-search"></i>
        <a href="<?php the_permalink(); ?>"><?php the_title();?></a>
        </h3>
      <?php if (has_post_thumbnail() ) { ?>
        <?php the_post_thumbnail( 'medium', array( 'class' => 'img-responsive alignleft img-thumbnail' ) ); ?>
      <?php }?>
        <?php the_excerpt(); ?>
      <a class="btn btn-success" href="<?php the_permalink(); ?>"><?php echo VERMAIS ?></a> </li>
</div>




<?php endwhile; else: ?>

<br />
<div class="row row-com-margin">
    <h3><i class="fa fa-exclamation-triangle"></i> Nenhum resultado encontrado para "<?php echo $s ?>". Tente uma pesquisa diferente ou utilize o menu acima para navegar.</h3>
    <br />
    <form action="<?php echo home_url( '/' ); ?>" method="get" class="form-inline">
        <fieldset>
            <div class="input-group form-searh">
                <input type="text" name="s" id="search" placeholder="<?php _e("Buscar","wpbootstrap"); ?>" value="<?php the_search_query(); ?>" class="form-control" />
                <span class="input-group-btn">
                    <button type="submit" class="btn btn-success"><?php _e('<i class="fa fa-search"></i>','wpbootstrap'); ?></button>
                </span>
            </div>
        </fieldset>
    </form>
       
</div>
<?php endif; ?>
<br />

 <?php paginacao();?>


<div class="row container-taxonomias padding-bottom-15">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-right">
        <a class="btn btn-success" href="javascript:history.back();"><< Voltar</a>
    </div>
</div>
