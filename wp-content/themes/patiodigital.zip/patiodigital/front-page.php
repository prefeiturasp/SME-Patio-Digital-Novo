<?php
/*
 * Template Name: Home
 * Description: Página Inicial do Site.
 */
 ?>
<?php get_header() ?>

<?php get_template_part('loop', 'front-page'); ?>

<?php get_footer() ?>
