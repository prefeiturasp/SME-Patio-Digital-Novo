<br>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="row container-taxonomias">
        <div class='col-12'>
            <h2 class="titulo-taxonomias"><i class="fa fa-th-large"></i>
				<?php the_title(); ?>
            </h2>
			<?php if (has_post_thumbnail()) {
				the_post_thumbnail('medium', array('class' => 'img-fluid alignleft img-thumbnail'));
			} ?>
			<?php the_content(); ?>
        </div>
    </div>
	<?php comments_template() ?>
	<?php
endwhile;
else: ?>
    <p>
		<?php _e('Não existem posts cadastrados.', 'patiodigital'); ?>
    </p>
<?php endif; ?>

<br/>
<div class="row container-taxonomias padding-bottom-15">
    <div class="col-12 text-right">
        <a class="btn btn-success" href="javascript:history.back();"><< Voltar</a>
    </div>
</div>
