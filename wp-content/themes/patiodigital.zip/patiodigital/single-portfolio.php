<?php
use Classes\TemplateHierarchy\Portfolio\SinglePortfolio;
get_header();
$template_hierarchy = new SinglePortfolio();
get_footer()
?>
